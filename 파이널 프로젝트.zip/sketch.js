// 뱀의 형상은 작은 조각(segment)들로 구성되는데,
// 이는 매 'draw' 호출에서 그려지고 수정됩니다.
let numSegments = 10;
let direction = 'right';

let xStart = 0; // 뱀의 시작 x좌표
let yStart = 250; // 뱀의 시작 y좌표
let diff = 10;

let xCor = [];
let yCor = [];

let xdot = 0;
let ydot = 0;
let PointElem;

function setup() {
  PointElem = createDiv('Point = 0');
  PointElem.position(20, 20);
  PointElem.id = 'Point';
  PointElem.style('color', 'brown');

  createCanvas(600, 600);
  frameRate(15);
  stroke(500);
  strokeWeight(13);
  updatedotCoordinates();

  for (let i = 0; i < numSegments; i++) {
    xCor.push(xStart + i * diff);
    yCor.push(yStart);
  }
}

function draw() {
  background(0);
  for (let i = 0; i < numSegments - 1; i++) {
    line(xCor[i], yCor[i], xCor[i + 1], yCor[i + 1]);
  }
  updateSnakeCoordinates();
  checkGameStatus();
  checkFordot();
}

/*
 뱀의 방향에 따라, 뱀의 형상을 구성하는 작은 조각(segment)들의 위치가 업데이트됩니다.
 0에서 n-1까지의 모든 조각들은 n에 도달할 때까지 그 다음 조각의 위치를 복사합니다.
 예를 들어, segment 0은 segment 1의 값을 받고, segment 1은 segment 2의 값을 받습니다. 뱀은 이러한 과정을 통해 움직이는 것입니다.
 이 때, 마지막 조각(segment)은 뱀이 가는 방향에 따라 추가됩니다. 
 뱀이 좌우로 움직일 때 가장 마지막 조각의 x값은, 마지막에서 두번째 조각의 x값보다 'diff'값만큼 증가합니다.
 뱀이 상하로 움직일 때는 가장 마지막 조각의 y값이 증가하는 식입니다.
*/
function updateSnakeCoordinates() {
  for (let i = 0; i < numSegments - 1; i++) {
    xCor[i] = xCor[i + 1];
    yCor[i] = yCor[i + 1];
  }
  switch (direction) {
    case 'right':
      xCor[numSegments - 1] = xCor[numSegments - 2] + diff;
      yCor[numSegments - 1] = yCor[numSegments - 2];
      break;
    case 'up':
      xCor[numSegments - 1] = xCor[numSegments - 2];
      yCor[numSegments - 1] = yCor[numSegments - 2] - diff;
      break;
    case 'left':
      xCor[numSegments - 1] = xCor[numSegments - 2] - diff;
      yCor[numSegments - 1] = yCor[numSegments - 2];
      break;
    case 'down':
      xCor[numSegments - 1] = xCor[numSegments - 2];
      yCor[numSegments - 1] = yCor[numSegments - 2] + diff;
      break;
  }
}

/*
 전 항상 뱀의 머리 위치인 xCor[xCor.length - 1]와
 yCor[yCor.length - 1]를 확인하여 뱀이 화면 경계나 자신의 몸에 닿는지를 본답니다.
*/
function checkGameStatus() {
  if (
    xCor[xCor.length - 2] > width ||
    xCor[xCor.length - 2] < 0 ||
    yCor[yCor.length - 2] > height ||
    yCor[yCor.length - 2] < 0 ||
    checkSnakeCollision()
  ) {
    noLoop();
    let PointVal = parseInt(PointElem.html().substring(8));
    PointElem.html('GAME OVER! Your Point : ' + PointVal);
  }
}

/*
 뱀이 자신의 몸에 닿았다는건 다시말해, 뱀의 머리의 (x,y)좌표가
 조각(segment)들 중 한 (x,y)좌표와 일치한다는 것입니다.
*/
function checkSnakeCollision() {
  let snakeHeadX = xCor[xCor.length - 2];
  let snakeHeadY = yCor[yCor.length - 2];
  for (let i = 0; i < xCor.length - 2; i++) {
    if (xCor[i] === snakeHeadX && yCor[i] === snakeHeadY) {
      return true;
    }
  }
}

/*
 뱀이 과일을 먹을 때마다 조각의 수가 증가하고, 배열의 시작에 꼬리 조각이 다시 삽입되도록 설정했습니다.(기본적으로, 마지막 조각을 꼬리 부분에 추가하여 꼬리를 늘리는 식이지요.)
*/
function checkFordot() {
  point(xdot, ydot);
  if (xCor[xCor.length - 2] === xdot && yCor[yCor.length - 2] === ydot) {
    let prevPoint = parseInt(PointElem.html().substring(8));
    PointElem.html('Point = ' + (prevPoint + 10));
    xCor.unshift(xCor[0]);
    yCor.unshift(yCor[0]);
    numSegments++;
    updatedotCoordinates();
  }
}

function updatedotCoordinates() {
  /*
    여기서 복잡한 연산 논리가 추가된 이유는
    뱀이 10의 배수 단위로 움직이도록 설정했기 때문입니다.
    점을 너비 100과 -100 사이에 있도록 하고,
    그 위치값이 가장 가까운 10의 배수 숫자로 반올림되도록 처리하였습니다.
  */

  xdot = floor(random(10, (width - 150) / 10)) * 10;
  ydot = floor(random(10, (height - 150) / 10)) * 10;
}

function keyPressed() {
  switch (keyCode) {
    case 65:
      if (direction !== 'right') {
        direction = 'left';
      }
      break;
    case 68:
      if (direction !== 'left') {
        direction = 'right';
      }
      break;
    case 87:
      if (direction !== 'down') {
        direction = 'up';
      }
      break;
    case 83:
      if (direction !== 'up') {
        direction = 'down';
      }
      break;
  }
}