
let numSegments = 10;
let direction = 'right';

let xStart = 0; 
let yStart = 250;
let diff = 10;

let xCor = [];
let yCor = [];

let xdot = 0;
let ydot = 0;
let PointElem;

function setup() {
  PointElem = createDiv('Point = 0');
  PointElem.position(20, 20);
  PointElem.id = 'Point';
  PointElem.style('color', 'brown');

  createCanvas(600, 600);
  frameRate(15);
  stroke(500);
  strokeWeight(13);
  updatedotCoordinates();

  for (let i = 0; i < numSegments; i++) {
    xCor.push(xStart + i * diff);
    yCor.push(yStart);
  }
}

function draw() {
  background(0);
  for (let i = 0; i < numSegments - 1; i++) {
    line(xCor[i], yCor[i], xCor[i + 1], yCor[i + 1]);
  }
  updateSnakeCoordinates();
  checkGameStatus();
  checkFordot();
}

function updateSnakeCoordinates() {
  for (let i = 0; i < numSegments - 1; i++) {
    xCor[i] = xCor[i + 1];
    yCor[i] = yCor[i + 1];
  }
  switch (direction) {
    case 'right':
      xCor[numSegments - 1] = xCor[numSegments - 2] + diff;
      yCor[numSegments - 1] = yCor[numSegments - 2];
      break;
    case 'up':
      xCor[numSegments - 1] = xCor[numSegments - 2];
      yCor[numSegments - 1] = yCor[numSegments - 2] - diff;
      break;
    case 'left':
      xCor[numSegments - 1] = xCor[numSegments - 2] - diff;
      yCor[numSegments - 1] = yCor[numSegments - 2];
      break;
    case 'down':
      xCor[numSegments - 1] = xCor[numSegments - 2];
      yCor[numSegments - 1] = yCor[numSegments - 2] + diff;
      break;
  }
}


function checkGameStatus() {
  if (
    xCor[xCor.length - 2] > width ||
    xCor[xCor.length - 2] < 0 ||
    yCor[yCor.length - 2] > height ||
    yCor[yCor.length - 2] < 0 ||
    checkSnakeCollision()
  ) {
    noLoop();
    let PointVal = parseInt(PointElem.html().substring(8));
    PointElem.html('GAME OVER! Your Point : ' + PointVal);
  }
}


function checkSnakeCollision() {
  let snakeHeadX = xCor[xCor.length - 2];
  let snakeHeadY = yCor[yCor.length - 2];
  for (let i = 0; i < xCor.length - 2; i++) {
    if (xCor[i] === snakeHeadX && yCor[i] === snakeHeadY) {
      return true;
    }
  }
}


function checkFordot() {
  point(xdot, ydot);
  if (xCor[xCor.length - 2] === xdot && yCor[yCor.length - 2] === ydot) {
    let prevPoint = parseInt(PointElem.html().substring(8));
    PointElem.html('Point = ' + (prevPoint + 10));
    xCor.unshift(xCor[0]);
    yCor.unshift(yCor[0]);
    numSegments++;
    updatedotCoordinates();
  }
}

function updatedotCoordinates() {
 
  xdot = floor(random(10, (width - 150) / 10)) * 10;
  ydot = floor(random(10, (height - 150) / 10)) * 10;
}

function keyPressed() {
  switch (keyCode) {
    case 65:
      if (direction !== 'right') {
        direction = 'left';
      }
      break;
    case 68:
      if (direction !== 'left') {
        direction = 'right';
      }
      break;
    case 87:
      if (direction !== 'down') {
        direction = 'up';
      }
      break;
    case 83:
      if (direction !== 'up') {
        direction = 'down';
      }
      break;
  }
}